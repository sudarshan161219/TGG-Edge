<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModuleInstance extends Model
{
    //
    protected $connection = 'mysql2';
    protected $table = 'module_instances';
    protected $guarded = ['id'];

    public function module()
    {
        return $this->belongsTo(Module::class);
    }

    public function moduleInstanceAssign()
    {
        return $this->belongsTo(ModuleInstanceAssign::class);
    }

    // Each instance belongs to a user
    public function user()
    {
        return $this->belongsTo(UserSecondary::class, 'user_id', 'id');
    } 

     public function literatures()
    {
        return $this->hasMany(Literature::class, 'module_instance_id');
    }
    
    
    public function links()
    {
        return $this->hasMany(Link::class, 'module_instance_id');
    }

     public function videos()
    {
        return $this->hasMany(Video::class, 'module_instance_id');
    }


}
