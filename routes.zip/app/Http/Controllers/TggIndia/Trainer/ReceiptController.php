<?php

namespace App\Http\Controllers\TggIndia\Trainer;

use App\Http\Controllers\Controller;
use App\Models\Receipt;
use App\Models\UserSecondary;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ReceiptController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $receipts = Receipt::with(['source', 'target'])->where('source_id',auth('web2')->id())->latest()->paginate(10);
        return view('tgg-india.trainer.receipts.index', compact('receipts'));

    }

    public function create()
    {
        $users = UserSecondary::select('id', 'name', 'email')->get();
        return view('tgg-india.trainer.receipts.create', compact('users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'issue_date' => 'nullable|date',
            'status' => 'nullable|string|max:50',
            'description' => 'nullable|string',
            'total' => 'nullable|numeric',
        ]);

        $receipt = Receipt::create([
            'receipt_number' => generateReceiptNumber(Auth('web2')->id()),
            'source_id' => Auth('web2')->id(),
            'target_id' => 1,
            'issue_date' => $request->issue_date,
            'status' => $request->status,
            'description' => $request->description,
            'total' => $request->total ?? null,
        ]);
        $items = $request->input('items', []);
        $receipt->items = $items;
        $receipt->save();

        return redirect()->route('tgg-india.trainer.receipts.index')->with('success', 'receipt created successfully.');
    
    }

    public function show(Receipt $receipt,$id)
    {
        $receipt =   Receipt::findOrFail($id);
        return view('tgg-india.trainer.receipts.show', compact('receipt'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $receipt = Receipt::findOrFail($id);
        $users = UserSecondary::select('id', 'name', 'email')->get();
        return view('tgg-india.trainer.receipts.edit', compact('receipt', 'users'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $receipt = Receipt::findOrFail($id);

        $receipt->update([
            'issue_date' => $request->issue_date,
            'status' => $request->status,
            'description' => $request->description,
            'total' => $request->total ?? null,
        ]);

        $items = $request->input('items', []);
        $receipt->items = $items;
        $receipt->save();

        return redirect()->route('tgg-india.trainer.receipts.index')->with('success', 'receipt updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $receipt = Receipt::findOrFail($id);

        $receipt->delete();

        return redirect()
            ->back()
            ->with('success', 'Receipt deleted successfully.');
    }

    public function download(Receipt $receipt, $id)
    {
      
        $receipt = Receipt::with(['source', 'target'])->findOrFail($id);
        $pdf = Pdf::loadView('tgg-india.trainer.receipts.pdf', compact('receipt'))
            ->setPaper('A4');
        $fileName = 'receipt_' . $receipt->receipt_number . '.pdf';
        $filePath = 'receipts/' . $fileName; 
        Storage::disk('public')->makeDirectory('receipts');
        Storage::disk('public')->put($filePath, $pdf->output());
        $receipt->update(['pdf_path' => $filePath]);
        return $pdf->download($fileName);
    }
}
